import torch
import os
import numpy as np
import time
import random

from clients.client_proposed import client_proposed
#from clients.client_DLF import client_DLF
from trainmodel.har_models import modality_model

from joblib import Parallel, delayed

#import gc
#import psutil

class ServerProposed(object):
    def __init__(self, args):
        # Set up the main attributes
        self.args = args
        self.device = args.device
        self.n_modalities = 9
        self.join_counts = [1] * self.n_modalities

        # init global models
        #self.global_models = [modality_model().to(self.device) for _ in range(self.n_modalities)]
        self.global_models = [modality_model() for _ in range(self.n_modalities)]
        self.modality_size = np.array([1.8, 0.2, 0.6, 1.4, 1.6, 0.4, 1.5, 0.5, 1])
        #self.selected_clients = []
        self.save_path = None
        self.K1 = args.num_clients
        self.U = args.U
        self.num_workers = args.num_workers
        self.communication_rounds = args.communication_rounds

        self.history_modalities = np.zeros((self.communication_rounds, self.n_modalities))
        self.history_clients = []
        self.clients_counts = np.zeros((30, 9))

        # init client
        clients = list(range(30))
        self.clients = []
        for client_id in clients:
            client_id += 1
            client = client_proposed(self.args, client_id=client_id)
            self.clients.append(client)
        self.selected_clients = self.clients

    def load_model(self, path=None):
        model_path = os.path.join(path, "server.pt")
        assert (os.path.exists(model_path))
        self.global_model = torch.load(model_path)

    def save_model(self, path=None):
        if path is None:
            path = self.save_path
        if not os.path.exists(path):
            os.makedirs(path)
        torch.save(self.global_model, os.path.join(path, "server.pt"))

    def test(self, is_fuse):
        Acc = []
        if not is_fuse:
            for client in self.clients:
                if client in self.selected_clients:
                    acc = client.test(is_fuse)
                    Acc.append(acc)
                else:
                    Acc.append(client.acc1)
            return np.mean(np.array(Acc), axis=0)
        else:
            for client in self.clients:
                acc = client.test(is_fuse)
                Acc.append(acc)
            return np.mean(np.array(Acc), axis=0)

    def receive_aggregate_models(self):
        self.join_counts = [0] * 9
        for client in self.selected_clients:
            for m in range(self.n_modalities):
                self.join_counts[m] += client.is_joins[m]

        for global_model in self.global_models:
            for param in global_model.parameters():
                param.data.zero_()
        #print(self.join_counts)

        # key: modality, value:all the local models
        for client in self.selected_clients:
            m = 0
            for model, is_join, join_counts, global_model in zip(client.models, client.is_joins, self.join_counts, self.global_models):
                if is_join:
                    self.clients_counts[client.client_id-1, m] += 1
                    for server_param, client_param in zip(global_model.parameters(), model.parameters()):
                        server_param.data += client_param.data.clone() * (1 / join_counts)
                m += 1

    def disperse_models(self):
        for client in self.clients:
            for model, is_join, global_model in zip(client.models, client.is_joins, self.global_models):
                for param, new_param in zip(model.parameters(), global_model.parameters()):
                    param.data = new_param.data.clone()

    def client_selection(self, beta1=10, beta2=15):
        self.selected_clients = []
        self.avg_modalities = np.array(self.join_counts) / len(self.clients)
        total_modality_size = []
        total_training_potential = []
        dist = []
        clientid = []
        for client in self.clients:
            clientid.append(client.client_id)
            # modality selection diversity
            dist.append(np.dot(np.array(client.is_joins), np.array(self.avg_modalities))/\
                          (np.linalg.norm(np.array(client.is_joins)) * np.linalg.norm(np.array(self.avg_modalities))))

            # total_modality_size
            total_modality_size.append(np.sum(self.modality_size[np.array(client.is_joins)==1]))

            # total_training_potential
            #total_training_potential.append(np.sum((client.acc2-client.acc1)[np.array(client.is_joins)==1]))
            selected_training_potential = 0
            for i in range(len(client.acc1)):
                if client.is_joins[i] == 1:
                    selected_training_potential += 0 - client.acc1[i] #client.acc2[i]
            total_training_potential.append(selected_training_potential)
        total_training_potential = np.array(total_training_potential)
        total_modality_size = np.array(total_modality_size)
        dist = np.array(dist)
        total_training_potential = (total_training_potential - np.min(total_training_potential)) / \
                                   (np.max(total_training_potential) - np.min(total_training_potential))

        client_importance = 0.1*dist + beta1*(total_training_potential) - beta2*(total_modality_size)
        print('arg:', np.argsort(- client_importance)[0:self.K1])
        selected_clients_id = np.argsort(- client_importance)[0:self.K1]

        for client in self.clients:
            if (client.client_id-1) in selected_clients_id:
                self.selected_clients.append(client)

        self.history_clients.append(selected_clients_id)

    def client_process(self, client):
        return client.client_process()

    def client_partialtrain(self, client):
        return client.local_train_partial()

    def train(self):
        acc_list = []
        acc_modality_list = []
        for epoch in range(self.communication_rounds):

            self.disperse_models()
            self.acc_modality = self.test(is_fuse=False)

            acc_modality_list.append(self.acc_modality)
            start = time.time()
            results = Parallel(n_jobs=self.num_workers, verbose=1)(
                delayed(self.client_partialtrain)(client)
                for client in self.clients
            )
            self.clients = results
            #self.receive_aggregate_models()

            results = Parallel(n_jobs=self.num_workers, verbose=1)(
                delayed(self.client_process)(client)
                for client in self.clients
            )

            self.clients = results
            # self.receive_aggregate_models()
            # acc_fuse = self.test(is_fuse=True)
            # acc_list.append(acc_fuse)

            self.client_selection()
            self.receive_aggregate_models()

            for i, client in enumerate(self.selected_clients):
                self.history_modalities[epoch, :] += np.array(client.is_joins)

            end = time.time()
            print('communication Round: ', epoch + 1, 'Time Cost:', end - start, 'ACC', np.mean(self.acc_modality))
            print(self.acc_modality)

            for i, client in enumerate(self.clients):
                self.clients_counts[i,:] = client.join_counts

        return acc_list, acc_modality_list

    def joins_count(self):
        client_counts = []
        for client in self.clients:
            client_counts.append(client.join_counts)
        return client_counts

