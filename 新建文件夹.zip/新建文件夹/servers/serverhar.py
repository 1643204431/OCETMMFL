import torch
import os
import numpy as np
import time
import random

from clients.client_proposed import client_proposed
from clients.client_DLF import client_DLF
from trainmodel.har_models import modality_model

class Server(object):
    def __init__(self, args):
        # Set up the main attributes
        self.args = args

        self.n_modalities = 9
        self.join_counts = [1] * self.n_modalities
        self.history_counts = []
        # init global models
        #self.global_models = [modality_model().to(self.device) for _ in range(self.n_modalities)]
        self.global_models = [modality_model() for _ in range(self.n_modalities)]
        self.modality_size = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1])
        self.selected_clients = []
        self.save_path = None
        self.method = 'DLF'
        # self.method = 'Proposed'

        # init client
        clients = list(range(30))
        self.clients = []
        for client_id in clients:
            client_id += 1
            client = client_proposed(self.args, client_id=client_id)
            self.clients.append(client)
        self.clients_counts = np.zeros((30, 9))
        self.communication_rounds = args.global_rounds
        self.U = 5
        self.K1 = args.num_clients
        self.U = args.U

    def load_model(self, path=None):
        model_path = os.path.join(path, "server.pt")
        assert (os.path.exists(model_path))
        self.global_model = torch.load(model_path)

    def save_model(self, path=None):
        if path is None:
            path = self.save_path
        if not os.path.exists(path):
            os.makedirs(path)
        torch.save(self.global_model, os.path.join(path, "server.pt"))


    def test(self, is_fuse):
        Acc = []
        if is_fuse:
            for client in self.clients:
                acc = client.test(is_fuse)
                Acc.append(acc)
            return Acc
        else:
            for client in self.clients:
                client.test(is_fuse)

    def receive_aggregate_models(self):
        self.join_counts = [0] * 9
        for client in self.selected_clients:
            for m in range(self.n_modalities):
                self.join_counts[m] += client.is_joins[m]

        self.history_counts.append(self.join_counts)

        for global_model in self.global_models:
            for param in global_model.parameters():
                param.data.zero_()
        #print(self.join_counts)

        # key: modality, value:all the local models
        for client in self.selected_clients:
            m = 0
            for model, is_join, join_counts, global_model in zip(client.models, client.is_joins, self.join_counts, self.global_models):
                if is_join:
                    self.clients_counts[client.client_id-1, m] += 1
                    for server_param, client_param in zip(global_model.parameters(), model.parameters()):
                        server_param.data += client_param.data.clone() * (1 / join_counts)
                m += 1

    def disperse_models(self):
        for client in self.clients:
            for model, join_counts, global_model in zip(client.models, self.join_counts, self.global_models):
                if join_counts > 0:
                    for param, new_param in zip(model.parameters(), global_model.parameters()):
                        param.data = new_param.data.clone()

    def train(self):
        acc_list = []
        for epoch in range(self.communication_rounds):

            self.disperse_models()

            if epoch % self.U == 0:
                start = time.time()
                self.test(is_fuse=False)
                for client in self.clients:
                    client.local_train()
                    client.modality_selection()

                acc = self.test(is_fuse=True)
                acc_list.append(np.mean(acc))

                self.client_selection()
                self.receive_aggregate_models()
                end = time.time()
                print(end - start, np.mean(acc))

            else:
                start = time.time()
                for client in self.selected_clients:
                    client.local_train()
                    client.modality_selection()
                    self.receive_aggregate_models()
                end = time.time()
                print(end - start)

        return acc_list

    def joins_count(self):
        client_counts = []
        for client in self.clients:
            client_counts.append(client.join_counts)
        return client_counts

