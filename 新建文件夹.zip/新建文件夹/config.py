import argparse

parser = argparse.ArgumentParser()
# general
parser.add_argument('-go', "--goal", type=str, default="test",
                    help="The goal for this experiment")
parser.add_argument('-dev', "--device", type=str, default="cuda",
                    choices=["cpu", "cuda"])
parser.add_argument('-did', "--device_id", type=str, default="0")
parser.add_argument('-data', "--dataset", type=str, default="har")
parser.add_argument('-nb', "--num_classes", type=int, default=6)
parser.add_argument('-lbs', "--batch_size", type=int, default=8)
parser.add_argument('-lr', "--local_learning_rate", type=float, default=0.02,
                    help="Local learning rate")
parser.add_argument('-gr', "--communication_rounds", type=int, default=20)
parser.add_argument('-ls', "--local_steps", type=int, default=10)

parser.add_argument('-k1', "--num_clients", type=int, default=3,
                    help=" ")

parser.add_argument('-k2', "--num_modalities", type=int, default=5,
                    help=" ")

parser.add_argument('-u', "--U", type=int, default=5,
                    help=" ")

parser.add_argument('-nw', "--num_workers", type=int, default=8,
                    help=" ")

parser.add_argument('-method', "--method", type=str, default='proposed',
                    help=" ")

#parser.add_argument('-dataset', "--dataset", type=str, default='UCI-HAR',
#                    help=" ")

parser.add_argument('-sfn', "--save_folder_name", type=str, default='models')
args = parser.parse_args()