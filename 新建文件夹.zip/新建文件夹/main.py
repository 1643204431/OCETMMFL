#!/usr/bin/env python

import pandas as pd

import copy
import torch
import argparse
import os
import time
import warnings
import numpy as np
from config import args

from servers.server_proposed import ServerProposed

warnings.simplefilter("ignore")
torch.manual_seed(0)

def run(args):
    if not os.path.exists('results_M'):
        os.makedirs('results_M')

    if args.method == 'proposed':
        for k1 in [1, 3, 5]:
            for k2 in [1, 3, 5]:
                args.num_clients = k1
                args.num_modalities = k2
                print(args.num_clients, args.num_modalities)
                current_dir = os.getcwd()

                server = ServerProposed(args)
                acc_list, acc_modality_list = server.train()

                acc_list = pd.DataFrame(acc_list)

                csv1 = 'Proposed_ACC_K1={}_K2={}_U={}.csv'.format(args.num_clients, args.num_modalities, args.U)
                acc_list.to_csv(os.path.join(current_dir, 'results_M', csv1))

                clients_counts = pd.DataFrame(server.clients_counts)
                csv2 = 'Proposed_clientscounts_K1={}_K2={}_U={}.csv'.format(args.num_clients, args.num_modalities, args.U)
                clients_counts.to_csv(os.path.join(current_dir, 'results_M', csv2))

                history_modalities = pd.DataFrame(server.history_modalities)
                csv3 = 'Proposed_historymodalities_K1={}_K2={}_U={}.csv'.format(args.num_clients, args.num_modalities, args.U)
                history_modalities.to_csv(os.path.join(current_dir, 'results_M', csv3))

                history_clients = pd.DataFrame(server.history_clients)
                csv4 = 'Proposed_historyclients_K1={}_K2={}_U={}.csv'.format(args.num_clients, args.num_modalities, args.U)
                history_clients.to_csv(os.path.join(current_dir, 'results_M', csv4))

                acc_modality_list = pd.DataFrame(acc_modality_list)
                csv5 = 'Proposed_ACCM_K1={}_K2={}_U={}.csv'.format(args.num_clients, args.num_modalities, args.U)
                acc_modality_list.to_csv(os.path.join(current_dir, 'results_M', csv5))


if __name__ == "__main__":
    run(args)


