import numpy as np

from clients.clientbase import ClientBase

import torch
from torch.utils.data import Dataset, DataLoader


class client_proposed(ClientBase):
    def __init__(self, args, client_id):
        super(client_proposed, self).__init__(args, client_id)

    def client_process(self):
        # global loss
        trainloader = self.load_train_data()
        Outputs1 = []
        for model in self.models:
            m = 0
            outputs = []
            for x, y in trainloader:
                x = x[:, m, :, :]
                # x, y = x.to(self.device), y.to(self.device)
                output = model(x)
                # outputs.append(output.detach().cpu().numpy())
                outputs.append(output.detach().numpy())
            m += 1
            outputs = np.concatenate(outputs)
            Outputs1.append(outputs)
        # Outputs1 = [torch.from_numpy(M).to(self.device) for M in Outputs1]
        Outputs1 = [torch.from_numpy(M) for M in Outputs1]

        # local update
        for step in range(self.local_steps):
            for model, optimizer in zip(self.models, self.optimizers):
                m = 0
                for x, y in trainloader:
                    x = x[:, m, :, :]
                    #x, y = x.to(self.device), y.to(self.device)
                    optimizer.zero_grad()
                    output = model(x)
                    loss = self.loss(output, y)
                    loss.backward()
                    optimizer.step()
                m += 1

        # compute local loss
        Outputs2 = []
        for model in self.models:
            m = 0
            outputs = []
            Y = []
            for x, y in trainloader:
                x = x[:, m, :, :]
                # x, y = x.to(self.device), y.to(self.device)
                output = model(x)
                # outputs.append(output.detach().cpu().numpy())
                outputs.append(output.detach().numpy())
                # Y.append(y.detach().cpu().numpy())
                Y.append(y.detach().numpy())
            m += 1
            outputs = np.concatenate(outputs)
            Y = np.concatenate(Y)
            Outputs2.append(outputs)

        Y = torch.from_numpy(Y)  # .to(self.device)
        # Outputs2 = [torch.from_numpy(M).to(self.device) for M in Outputs2]
        Outputs2 = [torch.from_numpy(M) for M in Outputs2]

        # fusion
        for w in self.FusionNet.weights:
            w.parm.data = torch.FloatTensor([0.5])
        #self.fusion.to(self.device)
        train_set = dataset_prediction_proposed(x1=Outputs1, x2=Outputs2, y=Y)
        train_set_iter = DataLoader(dataset=train_set, batch_size=8, shuffle=True, drop_last=False)
        for step in range(3):
            for batch_index, (x1, x2, y) in enumerate(train_set_iter):
                self.fusion_optimizer.zero_grad()
                fusion2 = self.FusionNet(x2)
                loss = self.loss(fusion2, y)
                loss.backward()
                self.fusion_optimizer.step()
                for p in self.FusionNet.parameters():
                    p.data.clamp_(0, 1)

        # modality selection
        self.is_joins = [1] * self.n_modalities
        parms = []
        for weight in self.FusionNet.weights:
            #parms.append(weight.parm.detach().cpu().numpy()[0])
            parms.append(weight.parm.detach().numpy()[0])
        parms = np.array(parms)
        modality_importance_id = np.argsort(- parms)

        for m in range(self.n_modalities):
            if m not in modality_importance_id[0:self.K2]:
                self.is_joins[m] = 0

        #print(self.is_joins)

        for m in range(self.n_modalities):
            if m in modality_importance_id[0:self.K2]:
                self.join_counts[m] += 1

        return self

class dataset_prediction_proposed(Dataset):
    def __init__(self, x1, x2, y):
        self.len = len(x1)
        self.features_global = x1
        self.features_local = x2
        self.target = y

    def __getitem__(self, index):
        return [feature[index] for feature in self.features_global], [feature[index] for feature in self.features_local], self.target[index]

    def __len__(self):
        return self.len